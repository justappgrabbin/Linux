# SynthAIPro All-in-One Container

This is the single-container version:

- SynthAIPro frontend
- Synthia-server backend
- WebSocket endpoint
- Boot terminal UI
- Interface switcher

No Render. No separate frontend container. No separate API URL.

## Layout

Put both repos beside this Dockerfile:

```text
selfhost/
  Dockerfile
  docker-compose.yml
  .env
  SynthAIPro/
  Synthia-server/
```

## Run On Windows

```bash
.\start.ps1
```

## Run On Linux Or Mac

```bash
chmod +x ./start.sh
./start.sh
```

Open:

```text
http://localhost:8080
```

From your phone on the same Wi-Fi, open:

```text
http://YOUR-COMPUTER-IP:8080
```

The app uses same-origin `/api/...`, `/health`, and `/ws`, so it does not need hosted service URLs.

## Terminal

Set this in `.env` if you want the in-app terminal to run commands:

```env
TERMINAL_TOKEN=choose-a-long-private-token
```

The app will autoboot the self-service terminal when it opens.
