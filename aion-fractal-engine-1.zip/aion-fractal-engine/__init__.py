"""
AION Fractal Engine - Main Entry Point
The complete autopoietic intelligence substrate.
"""

from core.AIONOrchestrator import AIONOrchestrator, Scale, Dimension
from core.tools.KleinTools import (
    DISEMINER, AUTOLING, AUTOCODER, MORPH,
    DISCRIMINATOR, ROUTER, GENERATOR, STORYTELLER,
    AdversarialGenerator
)
from core.fractal.FractalArbiter import FractalArbiter, ScaleBridge
from core.dimensional.DimensionalEngine import DimensionalQuestionEngine, DimensionalAnalyzer
from core.machines.MacroMachines import MovieMachine, GameMachine, OSMachine
from core.SelfModificationController import SelfModificationController

__version__ = "2.0.0"
__author__ = "AION"

__all__ = [
    'AIONOrchestrator',
    'Scale', 'Dimension',
    'DISEMINER', 'AUTOLING', 'AUTOCODER', 'MORPH',
    'DISCRIMINATOR', 'ROUTER', 'GENERATOR', 'STORYTELLER',
    'AdversarialGenerator',
    'FractalArbiter', 'ScaleBridge',
    'DimensionalQuestionEngine', 'DimensionalAnalyzer',
    'MovieMachine', 'GameMachine', 'OSMachine',
    'SelfModificationController'
]
