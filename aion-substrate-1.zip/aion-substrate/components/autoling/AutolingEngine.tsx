"use client";

import React, { useState } from 'react';
import { usePyodide } from '@/components/pyodide/PyodideProvider';
import { useSupabase } from '@/components/supabase/SupabaseProvider';

interface QuestionResult {
  dimension: string;
  question: string;
  findings: any[];
  confidence: number;
}

interface Hypothesis {
  statement: string;
  evidence: string[];
  confidence: number;
  test_proposal: string;
  expected_outcome: string;
}

export function AutolingEngine() {
  const { runPythonAsync } = usePyodide();
  const { supabase } = useSupabase();
  const [query, setQuery] = useState('');
  const [dimension, setDimension] = useState<'who' | 'what' | 'where' | 'when' | 'why' | 'how'>('what');
  const [results, setResults] = useState<QuestionResult[]>([]);
  const [hypotheses, setHypotheses] = useState<Hypothesis[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState<'query' | 'hypothesis' | 'code'>('query');

  const dimensions = [
    { id: 'who', label: 'Who', desc: 'Actors, agents, authors, entities', color: '#e94560' },
    { id: 'what', label: 'What', desc: 'Objects, content, artifacts', color: '#44ff44' },
    { id: 'where', label: 'Where', desc: 'Location, context, placement', color: '#44aaff' },
    { id: 'when', label: 'When', desc: 'Timing, sequence, cycles', color: '#ffaa00' },
    { id: 'why', label: 'Why', desc: 'Purpose, causality, intent', color: '#d4af37' },
    { id: 'how', label: 'How', desc: 'Mechanism, process, method', color: '#aa44ff' },
  ];

  const executeQuery = async () => {
    if (!query.trim()) return;
    setIsProcessing(true);

    try {
      const { data: meshData } = await supabase.from('mesh_nodes').select('*');

      const pythonQuery = `
import json
import re

def analyze_mesh(query, dimension, mesh_data):
    results = []
    query_lower = query.lower()

    for node in mesh_data:
        props = node.get('properties', {})
        score = 0
        match = False

        if dimension == 'who':
            if any(kw in query_lower for kw in ['author', 'creator', 'agent', 'person', 'who']):
                if props.get('owner_agent_id') or node.get('type') == 'agent':
                    score = 0.8
                    match = True
        elif dimension == 'what':
            if any(kw in query_lower for kw in ['file', 'code', 'function', 'class', 'content']):
                if props.get('name') and any(kw in props.get('name', '').lower() for kw in query_lower.split()):
                    score = 0.9
                    match = True
                content = json.dumps(props.get('parsed_data', {})).lower()
                if any(kw in content for kw in query_lower.split()):
                    score = 0.7
                    match = True
        elif dimension == 'where':
            if any(kw in query_lower for kw in ['path', 'location', 'domain', 'folder']):
                if props.get('path') or props.get('domain_tags'):
                    score = 0.8
                    match = True
        elif dimension == 'when':
            if any(kw in query_lower for kw in ['when', 'date', 'time', 'created', 'modified']):
                if props.get('created_at') or props.get('modified_at'):
                    score = 0.7
                    match = True
        elif dimension == 'why':
            if any(kw in query_lower for kw in ['purpose', 'why', 'intent', 'reason', 'goal']):
                if props.get('purpose_tags') or props.get('domain_tags'):
                    score = 0.7
                    match = True
        elif dimension == 'how':
            if any(kw in query_lower for kw in ['how', 'process', 'method', 'algorithm', 'mechanism']):
                if props.get('parsed_data') or node.get('type') == 'code':
                    score = 0.7
                    match = True

        if match:
            results.append({
                'node_id': node.get('id'),
                'name': props.get('name', 'Unknown'),
                'type': node.get('type'),
                'score': score,
                'properties': props
            })

    results.sort(key=lambda x: x['score'], reverse=True)
    return json.dumps(results[:20])

analyze_mesh(query, dimension, mesh_data)
      `;

      const result = await runPythonAsync(pythonQuery, {
        query, dimension, mesh_data: JSON.stringify(meshData || [])
      });

      const findings = JSON.parse(result);

      setResults(prev => [...prev, {
        dimension, question: query, findings,
        confidence: findings.length > 0 ? findings[0].score : 0
      }]);

      if (findings.length > 0 && findings[0].score > 0.7) {
        generateHypothesis(query, dimension, findings);
      }
    } catch (err) {
      console.error('Query error:', err);
    } finally {
      setIsProcessing(false);
      setQuery('');
    }
  };

  const generateHypothesis = async (query: string, dimension: string, findings: any[]) => {
    const hypothesisCode = `
import json

def generate_hypothesis(query, dimension, findings):
    hypothesis = {
        'statement': f"Based on {dimension} analysis of '{query}', we observe {len(findings)} significant patterns.",
        'evidence': [f["name"] for f in findings[:5]],
        'confidence': sum(f["score"] for f in findings[:5]) / len(findings[:5]) if findings else 0,
        'test_proposal': f"Cross-reference these {len(findings)} findings with other dimensions to validate resonance.",
        'expected_outcome': "Discovery of hidden relationships or emergent patterns in the mesh."
    }
    return json.dumps(hypothesis)

generate_hypothesis(query, dimension, findings)
    `;

    const result = await runPythonAsync(hypothesisCode, { query, dimension, findings: JSON.stringify(findings) });
    const hypothesis = JSON.parse(result);
    setHypotheses(prev => [hypothesis, ...prev]);
  };

  const generateCode = async () => {
    if (!query.trim()) return;
    setIsProcessing(true);

    const codePrompt = `
# User intent: ${query}
# Generate appropriate code based on mesh knowledge and intent

def generate_solution():
    if 'component' in '${query.lower()}' or 'react' in '${query.lower()}':
        return """import React from 'react';

export function GeneratedComponent() {
    return (
        <div className="p-4 bg-aion-matter rounded-lg border border-aion-resonance">
            <h2 className="text-aion-light font-bold">Generated: ${query}</h2>
            <p className="text-aion-light/70 mt-2">Auto-generated component</p>
        </div>
    );
}"""
    elif 'api' in '${query.lower()}' or 'endpoint' in '${query.lower()}':
        return """import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
    return NextResponse.json({ status: 'generated', intent: '${query}' });
}"""
    else:
        return "# Generated code for: ${query}\n# Please specify component, API, or utility"

generate_solution()
    `;

    try {
      const result = await runPythonAsync(codePrompt);
      setResults(prev => [...prev, {
        dimension: 'how' as any,
        question: `Generate code: ${query}`,
        findings: [{ generated_code: result }],
        confidence: 0.8
      }]);
    } catch (err) {
      console.error('Code generation error:', err);
    } finally {
      setIsProcessing(false);
      setQuery('');
    }
  };

  return (
    <div className="h-full flex flex-col gap-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-aion-light">AutoLing Engine</h2>
          <p className="text-aion-light/50 text-sm">Who / What / Where / When / Why / How → Hypothesis → Code</p>
        </div>
        <div className="flex gap-2">
          {['query', 'hypothesis', 'code'].map((tab) => (
            <button key={tab} onClick={() => setActiveTab(tab as any)}
              className={`px-4 py-2 rounded-lg text-sm capitalize ${activeTab === tab ? 'bg-aion-pulse text-white' : 'bg-aion-energy text-aion-light/60'}`}>
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-6 gap-2">
        {dimensions.map((dim) => (
          <button key={dim.id} onClick={() => setDimension(dim.id as any)}
            className={`p-3 rounded-lg text-center transition-all ${dimension === dim.id ? 'ring-2 ring-offset-2 ring-offset-aion-void' : 'opacity-60 hover:opacity-100'}`}
            style={{ backgroundColor: dim.color + '20', borderColor: dimension === dim.id ? dim.color : 'transparent', borderWidth: '1px' }}>
            <div className="text-lg font-bold" style={{ color: dim.color }}>{dim.label}</div>
            <div className="text-xs text-aion-light/50 mt-1">{dim.desc}</div>
          </button>
        ))}
      </div>

      <div className="flex gap-2">
        <input type="text" value={query} onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && (activeTab === 'code' ? generateCode() : executeQuery())}
          placeholder={`Ask ${dimension.toUpperCase()}...`}
          className="flex-1 bg-aion-matter border border-aion-resonance rounded-lg px-4 py-3 text-aion-light placeholder-aion-light/30 focus:outline-none focus:border-aion-pulse" />
        <button onClick={activeTab === 'code' ? generateCode : executeQuery}
          disabled={isProcessing || !query.trim()}
          className="px-6 py-3 bg-aion-pulse text-white rounded-lg font-medium hover:bg-aion-pulse/80 disabled:opacity-50">
          {isProcessing ? 'Processing...' : activeTab === 'code' ? 'Generate Code' : 'Query Mesh'}
        </button>
      </div>

      <div className="flex-1 overflow-auto space-y-4">
        {activeTab === 'query' && results.map((result, i) => (
          <div key={i} className="bg-aion-matter rounded-lg p-4 border border-aion-resonance">
            <div className="flex items-center gap-2 mb-3">
              <span className="px-2 py-1 rounded text-xs font-bold"
                style={{ backgroundColor: dimensions.find(d => d.id === result.dimension)?.color + '30', color: dimensions.find(d => d.id === result.dimension)?.color }}>
                {result.dimension.toUpperCase()}
              </span>
              <span className="text-aion-light font-medium">{result.question}</span>
              <span className="text-xs text-aion-light/50 ml-auto">Confidence: {(result.confidence * 100).toFixed(0)}%</span>
            </div>
            {result.findings.length > 0 ? (
              <div className="space-y-2">
                {result.findings.map((finding: any, j: number) => (
                  <div key={j} className="bg-aion-energy rounded-lg p-3 flex items-center justify-between">
                    <div>
                      <div className="text-aion-light font-medium">{finding.name || finding.node_id}</div>
                      <div className="text-xs text-aion-light/50">{finding.type}</div>
                    </div>
                    <div className="text-xs text-aion-pulse">Score: {(finding.score * 100).toFixed(0)}%</div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-aion-light/50 text-sm">No findings match this query in the current mesh.</p>
            )}
          </div>
        ))}

        {activeTab === 'hypothesis' && hypotheses.map((hyp, i) => (
          <div key={i} className="bg-aion-matter rounded-lg p-4 border border-aion-pulse/30">
            <div className="flex items-center gap-2 mb-3">
              <span className="w-2 h-2 rounded-full bg-aion-pulse animate-pulse" />
              <span className="text-aion-pulse font-bold text-sm">HYPOTHESIS</span>
              <span className="text-xs text-aion-light/50 ml-auto">Confidence: {(hyp.confidence * 100).toFixed(0)}%</span>
            </div>
            <p className="text-aion-light mb-3">{hyp.statement}</p>
            <div className="space-y-2">
              <div>
                <span className="text-xs text-aion-light/50">Evidence:</span>
                <div className="flex flex-wrap gap-2 mt-1">
                  {hyp.evidence.map((e: string, j: number) => (
                    <span key={j} className="px-2 py-1 bg-aion-energy rounded text-xs text-aion-light">{e}</span>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="bg-aion-energy rounded p-2">
                  <div className="text-aion-light/50 text-xs">Test Proposal</div>
                  <div className="text-aion-light">{hyp.test_proposal}</div>
                </div>
                <div className="bg-aion-energy rounded p-2">
                  <div className="text-aion-light/50 text-xs">Expected Outcome</div>
                  <div className="text-aion-light">{hyp.expected_outcome}</div>
                </div>
              </div>
            </div>
          </div>
        ))}

        {activeTab === 'code' && results.filter(r => r.dimension === 'how').map((result, i) => (
          <div key={i} className="bg-aion-matter rounded-lg p-4 border border-aion-resonance">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-aion-pulse font-bold">CODE GENERATION</span>
            </div>
            <pre className="bg-aion-void rounded-lg p-4 text-sm text-green-400 overflow-auto max-h-96 font-mono">
              {result.findings[0]?.generated_code || 'No code generated'}
            </pre>
          </div>
        ))}
      </div>
    </div>
  );
}
