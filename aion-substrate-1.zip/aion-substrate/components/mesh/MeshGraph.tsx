"use client";

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useSupabase } from '@/components/supabase/SupabaseProvider';
import { MeshNode, MeshEdge } from '@/types';

interface MeshGraphProps {
  filter?: string;
  highlightNode?: string;
  onNodeSelect?: (node: MeshNode) => void;
  layout?: 'force' | 'hierarchical' | 'circular' | 'body';
}

export function MeshGraph({ filter, highlightNode, onNodeSelect, layout = 'force' }: MeshGraphProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { supabase } = useSupabase();
  const [nodes, setNodes] = useState<MeshNode[]>([]);
  const [edges, setEdges] = useState<MeshEdge[]>([]);
  const [selectedNode, setSelectedNode] = useState<MeshNode | null>(null);
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const animationRef = useRef<number>();
  const nodePositions = useRef<Map<string, { x: number; y: number; vx: number; vy: number }>>(new Map());

  useEffect(() => {
    loadMesh();
    const subscription = supabase
      .channel('mesh_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'mesh_nodes' }, loadMesh)
      .subscribe();
    return () => { subscription.unsubscribe(); };
  }, [supabase]);

  const loadMesh = async () => {
    const { data: nodesData } = await supabase.from('mesh_nodes').select('*');
    const { data: edgesData } = await supabase.from('mesh_edges').select('*');
    if (nodesData) setNodes(nodesData);
    if (edgesData) setEdges(edgesData);
  };

  const simulateForces = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;

    nodes.forEach((node, i) => {
      if (!nodePositions.current.has(node.id)) {
        const angle = (i / nodes.length) * Math.PI * 2;
        const radius = Math.min(width, height) * 0.3;
        nodePositions.current.set(node.id, {
          x: centerX + Math.cos(angle) * radius,
          y: centerY + Math.sin(angle) * radius,
          vx: 0, vy: 0,
        });
      }
    });

    const positions = nodePositions.current;
    const repulsionForce = 5000;
    const attractionForce = 0.01;
    const centerForce = 0.05;

    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const posA = positions.get(nodes[i].id);
        const posB = positions.get(nodes[j].id);
        if (!posA || !posB) continue;
        const dx = posB.x - posA.x;
        const dy = posB.y - posA.y;
        const distance = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = repulsionForce / (distance * distance);
        const fx = (dx / distance) * force;
        const fy = (dy / distance) * force;
        posA.vx -= fx; posA.vy -= fy;
        posB.vx += fx; posB.vy += fy;
      }
    }

    edges.forEach((edge) => {
      const posA = positions.get(edge.source_id);
      const posB = positions.get(edge.target_id);
      if (!posA || !posB) return;
      const dx = posB.x - posA.x;
      const dy = posB.y - posA.y;
      const distance = Math.sqrt(dx * dx + dy * dy) || 1;
      const force = (distance - 100) * attractionForce * (edge.weight || 1);
      const fx = (dx / distance) * force;
      const fy = (dy / distance) * force;
      posA.vx += fx; posA.vy += fy;
      posB.vx -= fx; posB.vy -= fy;
    });

    positions.forEach((pos) => {
      const dx = centerX - pos.x;
      const dy = centerY - pos.y;
      pos.vx += dx * centerForce;
      pos.vy += dy * centerForce;
      pos.vx *= 0.9; pos.vy *= 0.9;
      pos.x += pos.vx; pos.y += pos.vy;
    });
  }, [nodes, edges]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const width = canvas.width;
    const height = canvas.height;

    ctx.fillStyle = '#0a0a0f';
    ctx.fillRect(0, 0, width, height);

    edges.forEach((edge) => {
      const posA = nodePositions.current.get(edge.source_id);
      const posB = nodePositions.current.get(edge.target_id);
      if (!posA || !posB) return;
      const isHighlighted = hoveredNode === edge.source_id || hoveredNode === edge.target_id;
      ctx.beginPath();
      ctx.moveTo(posA.x, posA.y);
      ctx.lineTo(posB.x, posB.y);
      ctx.strokeStyle = isHighlighted ? 'rgba(233, 69, 96, 0.6)' : 'rgba(100, 100, 150, 0.2)';
      ctx.lineWidth = isHighlighted ? 2 : 1;
      ctx.stroke();
    });

    nodes.forEach((node) => {
      const pos = nodePositions.current.get(node.id);
      if (!pos) return;
      const isHovered = hoveredNode === node.id;
      const isSelected = selectedNode?.id === node.id;
      const isHighlighted = highlightNode === node.id;
      const radius = (isHovered || isSelected) ? 12 : 8;

      let color = '#888';
      switch (node.subtype) {
        case 'code': color = '#44ff44'; break;
        case 'data': color = '#44aaff'; break;
        case 'media': color = '#ffaa00'; break;
        case 'image': color = '#ff44ff'; break;
        case 'archive': color = '#aa44ff'; break;
        case 'document': color = '#ffffff'; break;
        case 'agent': color = '#e94560'; break;
        case 'knowledge': color = '#d4af37'; break;
        default: color = '#888';
      }

      if (isHovered || isSelected || isHighlighted) {
        const gradient = ctx.createRadialGradient(pos.x, pos.y, 0, pos.x, pos.y, radius * 3);
        gradient.addColorStop(0, color + '40');
        gradient.addColorStop(1, 'transparent');
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, radius * 3, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, radius, 0, Math.PI * 2);
      ctx.fill();

      if (isHovered || isSelected || nodes.length < 50) {
        ctx.fillStyle = '#fff';
        ctx.font = '10px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(node.name.substring(0, 20), pos.x, pos.y + radius + 12);
      }
    });
  }, [nodes, edges, hoveredNode, selectedNode, highlightNode]);

  useEffect(() => {
    const animate = () => {
      simulateForces();
      draw();
      animationRef.current = requestAnimationFrame(animate);
    };
    animate();
    return () => { if (animationRef.current) cancelAnimationFrame(animationRef.current); };
  }, [simulateForces, draw]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    let clickedNode: MeshNode | null = null;
    nodes.forEach((node) => {
      const pos = nodePositions.current.get(node.id);
      if (!pos) return;
      const distance = Math.sqrt((x - pos.x) ** 2 + (y - pos.y) ** 2);
      if (distance < 20) clickedNode = node;
    });
    if (clickedNode) {
      setSelectedNode(clickedNode);
      onNodeSelect?.(clickedNode);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    let foundNode: string | null = null;
    nodes.forEach((node) => {
      const pos = nodePositions.current.get(node.id);
      if (!pos) return;
      const distance = Math.sqrt((x - pos.x) ** 2 + (y - pos.y) ** 2);
      if (distance < 20) foundNode = node.id;
    });
    setHoveredNode(foundNode);
  };

  return (
    <div className="relative w-full h-full bg-aion-void rounded-xl overflow-hidden">
      <canvas ref={canvasRef} width={1200} height={800}
        className="w-full h-full cursor-pointer"
        onClick={handleCanvasClick} onMouseMove={handleMouseMove} />

      {selectedNode && (
        <div className="absolute top-4 right-4 w-80 bg-aion-matter/90 backdrop-blur-md rounded-xl p-4 border border-aion-resonance">
          <h3 className="text-aion-light font-bold text-lg mb-2">{selectedNode.name}</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-aion-light/50">Type</span>
              <span className="text-aion-light">{selectedNode.subtype}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-aion-light/50">Domain</span>
              <span className="text-aion-light">{selectedNode.properties?.domain_tags?.join(', ') || 'Unknown'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-aion-light/50">Size</span>
              <span className="text-aion-light">{(selectedNode.properties?.size / 1024).toFixed(2)} KB</span>
            </div>
            {selectedNode.properties?.parsed_data && (
              <div className="mt-4 pt-4 border-t border-aion-resonance">
                <h4 className="text-aion-pulse font-medium mb-2">Parsed Structure</h4>
                <pre className="text-xs text-aion-light/70 overflow-auto max-h-40">
                  {JSON.stringify(selectedNode.properties.parsed_data, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="absolute bottom-4 left-4 bg-aion-matter/90 backdrop-blur-md rounded-xl p-3 border border-aion-resonance">
        <h4 className="text-aion-light text-xs font-bold mb-2">Mesh Legend</h4>
        <div className="space-y-1 text-xs">
          {[{color: '#44ff44', label: 'Code'}, {color: '#44aaff', label: 'Data'},
            {color: '#ffaa00', label: 'Media'}, {color: '#e94560', label: 'Agent'},
            {color: '#d4af37', label: 'Knowledge'}].map(({color, label}) => (
            <div key={label} className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{backgroundColor: color}} />
              <span className="text-aion-light/70">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
