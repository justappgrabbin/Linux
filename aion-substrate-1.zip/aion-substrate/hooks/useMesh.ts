"use client";

import { useState, useEffect, useCallback } from 'react';
import { useSupabase } from '@/components/supabase/SupabaseProvider';
import { MeshNode, MeshEdge } from '@/types';

export function useMesh() {
  const { supabase } = useSupabase();
  const [nodes, setNodes] = useState<MeshNode[]>([]);
  const [edges, setEdges] = useState<MeshEdge[]>([]);
  const [loading, setLoading] = useState(true);

  const loadMesh = useCallback(async () => {
    setLoading(true);
    const { data: nodesData } = await supabase.from('mesh_nodes').select('*');
    const { data: edgesData } = await supabase.from('mesh_edges').select('*');
    if (nodesData) setNodes(nodesData);
    if (edgesData) setEdges(edgesData);
    setLoading(false);
  }, [supabase]);

  const addNode = useCallback(async (node: Partial<MeshNode>) => {
    const { data, error } = await supabase.from('mesh_nodes').insert(node).select().single();
    if (error) throw error;
    setNodes(prev => [...prev, data]);
    return data;
  }, [supabase]);

  const addEdge = useCallback(async (edge: Partial<MeshEdge>) => {
    const { data, error } = await supabase.from('mesh_edges').insert(edge).select().single();
    if (error) throw error;
    setEdges(prev => [...prev, data]);
    return data;
  }, [supabase]);

  useEffect(() => {
    loadMesh();
  }, [loadMesh]);

  return { nodes, edges, loading, loadMesh, addNode, addEdge };
}
