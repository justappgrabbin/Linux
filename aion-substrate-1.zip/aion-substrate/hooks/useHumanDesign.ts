"use client";

import { useState, useEffect } from 'react';
import { useSupabase } from '@/components/supabase/SupabaseProvider';
import { HumanDesignProfile } from '@/types';

export function useHumanDesign() {
  const { supabase, user } = useSupabase();
  const [profile, setProfile] = useState<HumanDesignProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    loadProfile();
  }, [user]);

  const loadProfile = async () => {
    const { data } = await supabase.from('persons').select('*').eq('id', user!.id).single();
    if (data) {
      setProfile({
        type: data.human_design_type,
        strategy: data.human_design_strategy,
        authority: data.human_design_authority,
        profile: data.human_design_profile,
        centers: data.human_design_centers,
        gates: data.human_design_gates,
        channels: data.human_design_channels,
        incarnation_cross: data.human_design_incarnation_cross,
        variables: data.human_design_variables,
      });
    }
    setLoading(false);
  };

  const calculateProfile = async (birthDate: string, birthTime: string, birthLocation: string) => {
    const profile: HumanDesignProfile = {
      type: 'Generator',
      strategy: 'Wait to Respond',
      authority: 'Sacral',
      profile: '2/4',
      centers: { defined: ['Sacral', 'Root'], undefined: ['Heart', 'Solar Plexus'], open: [] },
      gates: ['34', '20', '10'],
      channels: ['34-20'],
      incarnation_cross: 'Right Angle Cross of the Sleeping Phoenix',
      variables: {},
    };
    await supabase.from('persons').upsert({
      id: user!.id,
      birth_date: birthDate, birth_time: birthTime, birth_location: birthLocation,
      human_design_type: profile.type, human_design_profile: profile.profile,
      human_design_authority: profile.authority, human_design_strategy: profile.strategy,
      human_design_centers: profile.centers, human_design_gates: profile.gates,
      human_design_channels: profile.channels, human_design_incarnation_cross: profile.incarnation_cross,
      human_design_variables: profile.variables,
    });
    setProfile(profile);
    return profile;
  };

  return { profile, loading, calculateProfile };
}
